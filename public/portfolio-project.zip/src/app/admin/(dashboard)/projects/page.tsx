"use client";

import { useEffect, useState, useRef } from "react";
import { useAuth } from "@/components/admin/AuthContext";
import ImageUpload from "@/components/admin/ImageUpload";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, GripVertical, X } from "lucide-react";

interface Project {
  id: string; title: string; description: string; longDescription: string; thumbnail: string;
  gallery: string[]; liveUrl: string; githubUrl: string; techStack: string[];
  features: string[]; category: string; featured: boolean; visible: boolean; order: number;
  seo: { title: string; description: string; keywords: string };
}

const emptyProject = {
  title: "", description: "", longDescription: "", thumbnail: "", gallery: [],
  liveUrl: "", githubUrl: "", techStack: [], features: [], category: "Web App",
  featured: false, visible: true, order: 0, seo: { title: "", description: "", keywords: "" },
};

export default function ProjectsAdmin() {
  const { token } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Project | null>(null);
  const [form, setForm] = useState(emptyProject);
  const [saving, setSaving] = useState(false);
  const [techInput, setTechInput] = useState("");
  const [featureInput, setFeatureInput] = useState("");

  // Gallery upload state
  const [galleryPreview, setGalleryPreview] = useState<string | null>(null);
  const [galleryFile, setGalleryFile] = useState<File | null>(null);
  const [galleryUploading, setGalleryUploading] = useState(false);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  const fetchRef = useRef(false);

  const fetchProjects = async () => {
    try {
      const res = await fetch("/api/projects?admin=true", { headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" } });
      if (res.ok) setProjects(await res.json());
    } catch {}
    setLoading(false);
  };

  useEffect(() => {
    if (!fetchRef.current && token) {
      fetchRef.current = true;
      fetchProjects();
    }
  }, [token]);

  const getHeaders = () => ({ Authorization: `Bearer ${token}`, "Content-Type": "application/json" });

  const handleSave = async () => {
    if (!form.title.trim()) { toast.error("Title is required"); return; }
    setSaving(true);
    try {
      const body = editing ? { id: editing.id, ...form } : form;
      const res = await fetch("/api/projects", { method: editing ? "PUT" : "POST", headers: getHeaders(), body: JSON.stringify(body) });
      if (res.ok) {
        toast.success(editing ? "Project saved to database ✓" : "Project created in database ✓");
        setOpen(false);
        setEditing(null);
        setForm(emptyProject);
        fetchProjects();
      } else {
        const errData = await res.json().catch(() => ({}));
        if (res.status === 503) {
          toast.error("Database not connected! Project was NOT saved.");
        } else {
          toast.error(errData.error || "Failed to save project");
        }
      }
    } catch {
      toast.error("Network error — project NOT saved.");
    }
    setSaving(false);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this project?")) return;
    try {
      const res = await fetch(`/api/projects?id=${id}`, { method: "DELETE", headers: getHeaders() });
      if (res.ok) { toast.success("Project deleted"); fetchProjects(); }
    } catch {}
  };

  const handleGalleryFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => setGalleryPreview(ev.target?.result as string);
    reader.readAsDataURL(file);
    setGalleryFile(file);
    e.target.value = "";
  };

  const confirmGalleryUpload = async () => {
    if (!galleryFile || !token) return;
    setGalleryUploading(true);
    try {
      const fd = new FormData();
      fd.append("file", galleryFile);
      fd.append("folder", "portfolio/projects");
      const res = await fetch("/api/upload", { method: "POST", headers: { Authorization: `Bearer ${token}` }, body: fd });
      if (res.ok) {
        const data = await res.json();
        setForm({ ...form, gallery: [...form.gallery, data.url] });
        toast.success("Gallery image added");
      } else {
        toast.error("Upload failed");
      }
    } catch {
      toast.error("Upload failed");
    } finally {
      setGalleryUploading(false);
      setGalleryPreview(null);
      setGalleryFile(null);
    }
  };

  const cancelGalleryPreview = () => {
    setGalleryPreview(null);
    setGalleryFile(null);
  };

  const openEdit = (p: Project) => {
    setEditing(p);
    setForm({ ...p, techStack: p.techStack || [], features: p.features || [], gallery: p.gallery || [], seo: p.seo || { title: "", description: "", keywords: "" } });
    setOpen(true);
  };

  const openCreate = () => {
    setEditing(null);
    setForm({ ...emptyProject, order: projects.length });
    setOpen(true);
  };

  const addTech = () => {
    if (techInput.trim() && !form.techStack.includes(techInput.trim())) {
      setForm({ ...form, techStack: [...form.techStack, techInput.trim()] });
      setTechInput("");
    }
  };

  const addFeature = () => {
    if (featureInput.trim() && !form.features.includes(featureInput.trim())) {
      setForm({ ...form, features: [...form.features, featureInput.trim()] });
      setFeatureInput("");
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-white">Projects</h1>
          <p className="text-zinc-500 mt-1">Manage your portfolio projects</p>
        </div>
        <Button onClick={openCreate} className="bg-emerald-500 hover:bg-emerald-400 text-zinc-950">
          <Plus className="h-4 w-4 mr-2" /> Add Project
        </Button>
      </div>

      {loading ? (
        <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="h-20 bg-zinc-900 rounded-xl animate-pulse" />)}</div>
      ) : (
        <div className="space-y-3">
          {projects.map((p) => (
            <Card key={p.id} className="bg-zinc-900/50 border-zinc-800 p-4 flex items-center gap-4">
              <GripVertical className="h-5 w-5 text-zinc-600 shrink-0" />
              <div className="w-16 h-12 bg-zinc-800 rounded-lg overflow-hidden shrink-0">
                {p.thumbnail ? <img src={p.thumbnail} alt="" className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-zinc-600 text-xs">No img</div>}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="font-medium text-white truncate">{p.title}</h3>
                  {p.featured && <Badge className="bg-emerald-500 text-zinc-950 border-0 text-xs">Featured</Badge>}
                  {!p.visible && <Badge variant="outline" className="text-xs border-zinc-700 text-zinc-500">Hidden</Badge>}
                </div>
                <p className="text-sm text-zinc-500 truncate">{p.description}</p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <Button size="sm" variant="ghost" onClick={() => openEdit(p)} className="text-zinc-400 hover:text-white">
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button size="sm" variant="ghost" onClick={() => handleDelete(p.id)} className="text-red-400 hover:text-red-300">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </Card>
          ))}
          {projects.length === 0 && <p className="text-zinc-500 text-center py-12">No projects yet. Add your first project!</p>}
        </div>
      )}

      {/* Create/Edit Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-zinc-950 border-zinc-800">
          <DialogHeader>
            <DialogTitle className="text-white">{editing ? "Edit Project" : "Add Project"}</DialogTitle>
          </DialogHeader>

          <div className="space-y-5">
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-zinc-300">Title *</Label>
                <Input value={form.title} onChange={(e) => setForm({...form, title: e.target.value})} className="bg-zinc-900 border-zinc-700 text-white" />
              </div>
              <div className="space-y-2">
                <Label className="text-zinc-300">Category</Label>
                <Select value={form.category} onValueChange={(v) => setForm({...form, category: v})}>
                  <SelectTrigger className="bg-zinc-900 border-zinc-700 text-white"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-zinc-900 border-zinc-700">
                    {["Web App", "SaaS", "AI/ML", "Mobile App", "E-Commerce", "Other"].map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-zinc-300">Short Description *</Label>
              <Textarea value={form.description} onChange={(e) => setForm({...form, description: e.target.value})} rows={2} className="bg-zinc-900 border-zinc-700 text-white resize-none" />
            </div>

            <div className="space-y-2">
              <Label className="text-zinc-300">Long Description</Label>
              <Textarea value={form.longDescription} onChange={(e) => setForm({...form, longDescription: e.target.value})} rows={4} className="bg-zinc-900 border-zinc-700 text-white resize-none" />
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-zinc-300">Live URL</Label>
                <Input value={form.liveUrl} onChange={(e) => setForm({...form, liveUrl: e.target.value})} className="bg-zinc-900 border-zinc-700 text-white" />
              </div>
              <div className="space-y-2">
                <Label className="text-zinc-300">GitHub URL</Label>
                <Input value={form.githubUrl} onChange={(e) => setForm({...form, githubUrl: e.target.value})} className="bg-zinc-900 border-zinc-700 text-white" />
              </div>
            </div>

            {/* Thumbnail Upload - with preview, confirm, cancel */}
            <div className="space-y-2">
              <Label className="text-zinc-300">Thumbnail</Label>
              <ImageUpload
                value={form.thumbnail}
                onChange={(url) => setForm({...form, thumbnail: url})}
                label="Upload Thumbnail"
                folder="portfolio/projects"
                token={token}
                previewClass="w-24 h-16"
              />
            </div>

            {/* Gallery */}
            <div className="space-y-2">
              <Label className="text-zinc-300">Gallery Images</Label>
              <div className="flex flex-wrap gap-2 mb-2">
                {form.gallery.map((img, i) => (
                  <div key={i} className="relative w-20 h-14 rounded-lg overflow-hidden border border-zinc-700 group">
                    <img src={img} alt="" className="w-full h-full object-cover" />
                    <button
                      onClick={() => setForm({...form, gallery: form.gallery.filter((_, j) => j !== i)})}
                      className="absolute top-0 right-0 p-0.5 bg-red-500 text-white rounded-bl opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ))}
              </div>

              {/* Gallery upload with preview */}
              {galleryPreview ? (
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <div className="w-20 h-14 rounded-lg overflow-hidden border-2 border-emerald-500/50">
                      <img src={galleryPreview} alt="Preview" className="w-full h-full object-cover" />
                    </div>
                    <div className="absolute -top-2 -right-2 flex gap-1">
                      <button
                        onClick={confirmGalleryUpload}
                        disabled={galleryUploading}
                        className="p-1 bg-emerald-500 text-white rounded-full hover:bg-emerald-400 transition-colors disabled:opacity-50"
                        title="Confirm"
                      >
                        {galleryUploading ? <span className="h-3 w-3 border-2 border-white border-t-transparent rounded-full animate-spin inline-block" /> : <span className="text-xs">✓</span>}
                      </button>
                      <button
                        onClick={cancelGalleryPreview}
                        disabled={galleryUploading}
                        className="p-1 bg-red-500 text-white rounded-full hover:bg-red-400 transition-colors disabled:opacity-50"
                        title="Cancel"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => galleryInputRef.current?.click()}
                  className="flex items-center gap-2 px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-sm text-zinc-300 hover:bg-zinc-700 hover:border-zinc-600 transition-colors"
                >
                  <span className="h-4 w-4">+</span> Add Image
                </button>
              )}
              <input
                ref={galleryInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleGalleryFileSelect}
              />
            </div>

            {/* Tech Stack */}
            <div className="space-y-2">
              <Label className="text-zinc-300">Tech Stack</Label>
              <div className="flex flex-wrap gap-1.5 mb-2">
                {form.techStack.map((t) => (
                  <Badge key={t} variant="outline" className="border-emerald-500/30 text-emerald-400 bg-emerald-500/5">
                    {t}
                    <button onClick={() => setForm({...form, techStack: form.techStack.filter(x => x !== t)})} className="ml-1 hover:text-red-400"><X className="h-3 w-3" /></button>
                  </Badge>
                ))}
              </div>
              <div className="flex gap-2">
                <Input value={techInput} onChange={(e) => setTechInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addTech())} placeholder="Add technology" className="bg-zinc-900 border-zinc-700 text-white flex-1" />
                <Button type="button" onClick={addTech} variant="outline" className="border-zinc-700 text-zinc-300">Add</Button>
              </div>
            </div>

            {/* Features */}
            <div className="space-y-2">
              <Label className="text-zinc-300">Features</Label>
              <div className="space-y-1 mb-2">
                {form.features.map((f, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm text-zinc-300">
                    <span>▸ {f}</span>
                    <button onClick={() => setForm({...form, features: form.features.filter((_, j) => j !== i)})} className="text-red-400 hover:text-red-300"><X className="h-3 w-3" /></button>
                  </div>
                ))}
              </div>
              <div className="flex gap-2">
                <Input value={featureInput} onChange={(e) => setFeatureInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addFeature())} placeholder="Add feature" className="bg-zinc-900 border-zinc-700 text-white flex-1" />
                <Button type="button" onClick={addFeature} variant="outline" className="border-zinc-700 text-zinc-300">Add</Button>
              </div>
            </div>

            {/* Toggles */}
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <Switch checked={form.featured} onCheckedChange={(v) => setForm({...form, featured: v})} />
                <Label className="text-zinc-300">Featured</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch checked={form.visible} onCheckedChange={(v) => setForm({...form, visible: v})} />
                <Label className="text-zinc-300">Visible</Label>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-zinc-300">Order</Label>
              <Input type="number" value={form.order} onChange={(e) => setForm({...form, order: parseInt(e.target.value) || 0})} className="bg-zinc-900 border-zinc-700 text-white w-24" />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} className="border-zinc-700 text-zinc-300">Cancel</Button>
            <Button onClick={handleSave} disabled={saving} className="bg-emerald-500 hover:bg-emerald-400 text-zinc-950">
              {saving ? "Saving..." : editing ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
