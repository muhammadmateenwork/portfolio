"use client";

import { useEffect, useState, useRef } from "react";
import { useAuth } from "@/components/admin/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, GripVertical } from "lucide-react";

interface CustomSection {
  id: string; sectionKey: string; title: string; subtitle: string; content: string; type: string; visible: boolean; order: number;
}

const emptySection = { sectionKey: "", title: "", subtitle: "", content: "", type: "text", visible: true, order: 0 };

export default function CustomSectionsAdmin() {
  const { token } = useAuth();
  const [sections, setSections] = useState<CustomSection[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<CustomSection | null>(null);
  const [form, setForm] = useState(emptySection);
  const [saving, setSaving] = useState(false);
  const fetchRef = useRef(false);

  const getHeaders = () => ({ Authorization: `Bearer ${token}`, "Content-Type": "application/json" });

  const fetchSections = async () => {
    try {
      const res = await fetch("/api/custom-sections?admin=true", { headers: getHeaders() });
      if (res.ok) setSections(await res.json());
    } catch {}
    setLoading(false);
  };

  useEffect(() => {
    if (!fetchRef.current && token) {
      fetchRef.current = true;
      // eslint-disable-next-line react-hooks/set-state-in-effect
      fetchSections();
    }
  }, [token]);

  const handleSave = async () => {
    if (!form.sectionKey.trim() || !form.title.trim()) { toast.error("Section key and title are required"); return; }
    setSaving(true);
    try {
      const body = editing ? { id: editing.id, ...form } : form;
      const res = await fetch("/api/custom-sections", { method: editing ? "PUT" : "POST", headers: getHeaders(), body: JSON.stringify(body) });
      if (res.ok) {
        toast.success(editing ? "Section updated" : "Section created");
        setOpen(false); setEditing(null); setForm(emptySection); fetchRef.current = false; fetchSections();
      } else { toast.error("Failed to save"); }
    } catch { toast.error("Something went wrong"); }
    setSaving(false);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this section?")) return;
    try {
      const res = await fetch(`/api/custom-sections?id=${id}`, { method: "DELETE", headers: getHeaders() });
      if (res.ok) { toast.success("Section deleted"); fetchRef.current = false; fetchSections(); }
    } catch {}
  };

  const openEdit = (s: CustomSection) => { setEditing(s); setForm({ ...s }); setOpen(true); };
  const openCreate = () => { setEditing(null); setForm({ ...emptySection, order: sections.length }); setOpen(true); };

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-white">Custom Sections</h1>
          <p className="text-zinc-500 mt-1">Manage custom content sections</p>
        </div>
        <Button onClick={openCreate} className="bg-emerald-500 hover:bg-emerald-400 text-zinc-950">
          <Plus className="h-4 w-4 mr-2" /> Add Section
        </Button>
      </div>

      {loading ? (
        <div className="space-y-3">{[1,2].map(i => <div key={i} className="h-16 bg-zinc-900 rounded-xl animate-pulse" />)}</div>
      ) : (
        <div className="space-y-3">
          {sections.map((s) => (
            <Card key={s.id} className="bg-zinc-900/50 border-zinc-800 p-4 flex items-center gap-4">
              <GripVertical className="h-5 w-5 text-zinc-600 shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="font-medium text-white">{s.title}</h3>
                  <Badge variant="outline" className="text-xs border-zinc-700 text-zinc-500">{s.sectionKey}</Badge>
                  <Badge variant="outline" className="text-xs border-zinc-700 text-zinc-500">{s.type}</Badge>
                  {!s.visible && <Badge variant="outline" className="text-xs border-zinc-700 text-zinc-500">Hidden</Badge>}
                </div>
                <p className="text-sm text-zinc-500 truncate">{s.subtitle || s.content.slice(0, 80)}</p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <Button size="sm" variant="ghost" onClick={() => openEdit(s)} className="text-zinc-400 hover:text-white"><Pencil className="h-4 w-4" /></Button>
                <Button size="sm" variant="ghost" onClick={() => handleDelete(s.id)} className="text-red-400 hover:text-red-300"><Trash2 className="h-4 w-4" /></Button>
              </div>
            </Card>
          ))}
          {sections.length === 0 && <p className="text-zinc-500 text-center py-12">No custom sections yet.</p>}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg bg-zinc-950 border-zinc-800">
          <DialogHeader><DialogTitle className="text-white">{editing ? "Edit Section" : "Add Section"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-zinc-300">Section Key *</Label>
                <Input value={form.sectionKey} onChange={(e) => setForm({...form, sectionKey: e.target.value.replace(/\s+/g, "-").toLowerCase()})} placeholder="e.g., process, testimonials" className="bg-zinc-900 border-zinc-700 text-white" disabled={!!editing} />
              </div>
              <div className="space-y-2">
                <Label className="text-zinc-300">Type</Label>
                <Select value={form.type} onValueChange={(v) => setForm({...form, type: v})}>
                  <SelectTrigger className="bg-zinc-900 border-zinc-700 text-white"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-zinc-900 border-zinc-700">
                    <SelectItem value="text">Plain Text</SelectItem>
                    <SelectItem value="markdown">Markdown</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-zinc-300">Title *</Label>
              <Input value={form.title} onChange={(e) => setForm({...form, title: e.target.value})} className="bg-zinc-900 border-zinc-700 text-white" />
            </div>
            <div className="space-y-2">
              <Label className="text-zinc-300">Subtitle</Label>
              <Input value={form.subtitle} onChange={(e) => setForm({...form, subtitle: e.target.value})} className="bg-zinc-900 border-zinc-700 text-white" />
            </div>
            <div className="space-y-2">
              <Label className="text-zinc-300">Content</Label>
              <Textarea value={form.content} onChange={(e) => setForm({...form, content: e.target.value})} rows={8} className="bg-zinc-900 border-zinc-700 text-white resize-none font-mono text-sm" placeholder={form.type === "markdown" ? "## Heading\n\nParagraph text..." : "Section content..."} />
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={form.visible} onCheckedChange={(v) => setForm({...form, visible: v})} />
              <Label className="text-zinc-300">Visible</Label>
            </div>
            <div className="space-y-2">
              <Label className="text-zinc-300">Order</Label>
              <Input type="number" value={form.order} onChange={(e) => setForm({...form, order: parseInt(e.target.value) || 0})} className="bg-zinc-900 border-zinc-700 text-white w-24" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} className="border-zinc-700 text-zinc-300">Cancel</Button>
            <Button onClick={handleSave} disabled={saving} className="bg-emerald-500 hover:bg-emerald-400 text-zinc-950">{saving ? "Saving..." : editing ? "Update" : "Create"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
