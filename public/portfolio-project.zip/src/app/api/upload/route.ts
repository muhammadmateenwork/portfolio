import { NextRequest, NextResponse } from "next/server";
import { verifyToken, getAuthHeader } from "@/lib/auth";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import { v2 as cloudinary } from "cloudinary";

// Configure Cloudinary SDK with server-side credentials
cloudinary.config({
  cloud_name: process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
  secure: true,
});

export async function POST(req: NextRequest) {
  try {
    const token = getAuthHeader(req.headers);
    if (!token || !verifyToken(token)) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const formData = await req.formData();
    const file = formData.get("file") as File;
    const folder = (formData.get("folder") as string) || "portfolio";

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    // Check if Cloudinary is fully configured with API key + secret (server-side upload)
    const apiKey = process.env.CLOUDINARY_API_KEY;
    const apiSecret = process.env.CLOUDINARY_API_SECRET;
    const cloudName = process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME;

    const cloudinaryFullyConfigured =
      cloudName && apiKey && apiSecret &&
      cloudName.length > 3 && apiKey.length > 3 && apiSecret.length > 3;

    if (cloudinaryFullyConfigured) {
      // Use Cloudinary SDK for server-side signed upload (most reliable)
      try {
        const bytes = await file.arrayBuffer();
        const buffer = Buffer.from(bytes);

        const result = await cloudinary.uploader.upload(
          `data:${file.type};base64,${buffer.toString("base64")}`,
          {
            folder,
            resource_type: "auto",
            use_filename: true,
            unique_filename: true,
          }
        );

        return NextResponse.json({
          url: result.secure_url,
          publicId: result.public_id,
          width: result.width,
          height: result.height,
          format: result.format,
          provider: "cloudinary",
        });
      } catch (cloudinaryError: unknown) {
        const errMsg = cloudinaryError instanceof Error ? cloudinaryError.message : String(cloudinaryError);
        console.error("Cloudinary upload failed, falling back to local:", errMsg);
        return await uploadToLocal(file, folder);
      }
    }

    // Check for unsigned upload preset (less reliable, but works without API secret)
    const uploadPreset = process.env.NEXT_PUBLIC_CLOUDINARY_UPLOAD_PRESET;
    const cloudinaryUnsignedConfigured =
      cloudName && uploadPreset &&
      cloudName.length > 3 && uploadPreset.length > 3;

    if (cloudinaryUnsignedConfigured) {
      try {
        const bytes = await file.arrayBuffer();
        const buffer = Buffer.from(bytes);

        const cloudinaryFormData = new FormData();
        cloudinaryFormData.append("file", new Blob([buffer], { type: file.type }), file.name);
        cloudinaryFormData.append("upload_preset", uploadPreset!);
        cloudinaryFormData.append("folder", folder);

        const response = await fetch(
          `https://api.cloudinary.com/v1_1/${cloudName}/auto/upload`,
          {
            method: "POST",
            body: cloudinaryFormData,
          }
        );

        if (!response.ok) {
          const errorData = await response.text();
          console.error("Cloudinary unsigned upload error:", errorData);
          return await uploadToLocal(file, folder);
        }

        const data = await response.json();
        return NextResponse.json({
          url: data.secure_url,
          publicId: data.public_id,
          width: data.width,
          height: data.height,
          format: data.format,
          provider: "cloudinary-unsigned",
        });
      } catch (cloudinaryError: unknown) {
        const errMsg = cloudinaryError instanceof Error ? cloudinaryError.message : String(cloudinaryError);
        console.error("Cloudinary unsigned upload failed, falling back to local:", errMsg);
        return await uploadToLocal(file, folder);
      }
    }

    // Local file upload fallback
    return await uploadToLocal(file, folder);
  } catch (error: unknown) {
    const errMsg = error instanceof Error ? error.message : String(error);
    console.error("Upload error:", errMsg);
    return NextResponse.json({ error: "Internal server error", details: errMsg }, { status: 500 });
  }
}

async function uploadToLocal(file: File, folder: string): Promise<NextResponse> {
  const bytes = await file.arrayBuffer();
  const buffer = Buffer.from(bytes);

  // Generate unique filename
  const ext = path.extname(file.name) || ".png";
  const uniqueName = `${Date.now()}-${Math.random().toString(36).substring(2, 8)}${ext}`;
  const relativePath = `uploads/${folder}/${uniqueName}`;
  const fullPath = path.join(process.cwd(), "public", relativePath);

  // Ensure directory exists
  await mkdir(path.dirname(fullPath), { recursive: true });

  // Write file
  await writeFile(fullPath, buffer);

  return NextResponse.json({
    url: `/${relativePath}`,
    publicId: relativePath,
    format: ext.replace(".", ""),
    provider: "local",
  });
}
