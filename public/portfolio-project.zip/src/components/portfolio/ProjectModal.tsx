"use client";

import { motion } from "framer-motion";
import {
  Dialog,
  DialogContent,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink, Github, X } from "lucide-react";

interface Project {
  id: string;
  title: string;
  description: string;
  longDescription: string;
  thumbnail: string;
  gallery: string[];
  liveUrl: string;
  githubUrl: string;
  techStack: string[];
  features: string[];
  category: string;
  featured: boolean;
}

interface ProjectModalProps {
  project: Project | null;
  open: boolean;
  onClose: () => void;
}

export default function ProjectModal({ project, open, onClose }: ProjectModalProps) {
  if (!project) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto bg-zinc-950 border-zinc-800 p-0">
        <DialogTitle className="sr-only">{project.title}</DialogTitle>

        {/* Header Image */}
        <div className="relative aspect-video bg-zinc-900">
          {project.thumbnail ? (
            <img
              src={project.thumbnail}
              alt={project.title}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-emerald-500/10 to-zinc-900 flex items-center justify-center">
              <span className="text-6xl font-bold text-emerald-500/20">{project.title.charAt(0)}</span>
            </div>
          )}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 bg-black/50 backdrop-blur-sm rounded-lg text-white hover:bg-black/70 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Title and Category */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="outline" className="border-zinc-700 text-zinc-400">
                {project.category}
              </Badge>
              {project.featured && (
                <Badge className="bg-emerald-500 text-zinc-950 border-0">Featured</Badge>
              )}
            </div>
            <h2 className="text-2xl font-bold text-white">{project.title}</h2>
          </div>

          {/* Description */}
          <p className="text-zinc-400 leading-relaxed">
            {project.longDescription || project.description}
          </p>

          {/* Features */}
          {project.features && project.features.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold text-white mb-3">Key Features</h3>
              <ul className="grid sm:grid-cols-2 gap-2">
                {project.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-2 text-zinc-400">
                    <span className="text-emerald-400 mt-1">▸</span>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Tech Stack */}
          {project.techStack && project.techStack.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold text-white mb-3">Tech Stack</h3>
              <div className="flex flex-wrap gap-2">
                {project.techStack.map((tech) => (
                  <Badge key={tech} variant="outline" className="border-emerald-500/30 text-emerald-400 bg-emerald-500/5">
                    {tech}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Gallery */}
          {project.gallery && project.gallery.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold text-white mb-3">Gallery</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {project.gallery.map((img, i) => (
                  <div key={i} className="aspect-video bg-zinc-900 rounded-lg overflow-hidden border border-zinc-800">
                    <img src={img} alt={`${project.title} screenshot ${i + 1}`} className="w-full h-full object-cover" loading="lazy" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Links */}
          <div className="flex gap-3 pt-2">
            {project.liveUrl && (
              <a href={project.liveUrl} target="_blank" rel="noopener noreferrer">
                <Button className="bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-semibold rounded-xl">
                  <ExternalLink className="mr-2 h-4 w-4" />
                  Live Demo
                </Button>
              </a>
            )}
            {project.githubUrl && (
              <a href={project.githubUrl} target="_blank" rel="noopener noreferrer">
                <Button variant="outline" className="border-zinc-700 text-zinc-300 hover:text-white rounded-xl">
                  <Github className="mr-2 h-4 w-4" />
                  Source Code
                </Button>
              </a>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
