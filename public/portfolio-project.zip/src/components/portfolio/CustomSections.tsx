"use client";

import { motion } from "framer-motion";
import ReactMarkdown from "react-markdown";
import SectionHeading from "./SectionHeading";

interface CustomSection {
  id: string;
  sectionKey: string;
  title: string;
  subtitle: string;
  content: string;
  type: string;
  visible: boolean;
  order: number;
}

interface CustomSectionsProps {
  sections: CustomSection[];
}

export default function CustomSections({ sections }: CustomSectionsProps) {
  if (!sections || sections.length === 0) return null;

  return (
    <>
      {sections.map((section) => (
        <section
          key={section.id}
          id={section.sectionKey}
          className="py-20 sm:py-28 bg-zinc-950"
        >
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <SectionHeading title={section.title} subtitle={section.subtitle} />
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="prose prose-invert prose-emerald max-w-none"
            >
              {section.type === "markdown" || section.type === "text" ? (
                <div className="space-y-4">
                  {section.content.split("\n\n").map((block, i) => {
                    if (block.startsWith("## ")) {
                      return (
                        <h3 key={i} className="text-xl font-semibold text-emerald-400 mt-8 mb-3">
                          {block.replace("## ", "")}
                        </h3>
                      );
                    }
                    return (
                      <p key={i} className="text-zinc-400 leading-relaxed">
                        {block}
                      </p>
                    );
                  })}
                </div>
              ) : (
                <div className="text-zinc-400 leading-relaxed" dangerouslySetInnerHTML={{ __html: section.content }} />
              )}
            </motion.div>
          </div>
        </section>
      ))}
    </>
  );
}
