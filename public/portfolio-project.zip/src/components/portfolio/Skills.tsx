"use client";

import { motion } from "framer-motion";
import SectionHeading from "./SectionHeading";

interface Skill {
  id: string;
  name: string;
  icon: string;
  category: string;
  proficiency: number;
  visible: boolean;
  order: number;
}

interface SkillsProps {
  skills: Skill[];
  sectionTitle: string;
}

const categoryColors: Record<string, string> = {
  Frontend: "from-emerald-500 to-emerald-400",
  Backend: "from-teal-500 to-teal-400",
  DevOps: "from-cyan-500 to-cyan-400",
  Other: "from-emerald-600 to-emerald-500",
};

export default function Skills({ skills, sectionTitle }: SkillsProps) {
  const categories = [...new Set(skills.map((s) => s.category))];

  return (
    <section id="skills" className="py-20 sm:py-28 bg-[#0a0a0a]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading title={sectionTitle || "Skills & Expertise"} />

        <div className="space-y-12">
          {categories.map((category) => {
            const categorySkills = skills.filter((s) => s.category === category);
            const gradientColor = categoryColors[category] || categoryColors.Other;

            return (
              <div key={category}>
                <h3 className="text-lg font-semibold text-zinc-300 mb-6 flex items-center gap-3">
                  <span className={`h-2 w-2 rounded-full bg-gradient-to-r ${gradientColor}`} />
                  {category}
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {categorySkills.map((skill, i) => (
                    <motion.div
                      key={skill.id}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.4, delay: i * 0.05 }}
                      className="group bg-zinc-900/50 border border-zinc-800 rounded-xl p-5 hover:border-emerald-500/30 transition-all duration-300"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-medium text-zinc-200 group-hover:text-emerald-400 transition-colors">
                          {skill.name}
                        </span>
                        <span className="text-sm text-zinc-500">{skill.proficiency}%</span>
                      </div>
                      <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          whileInView={{ width: `${skill.proficiency}%` }}
                          viewport={{ once: true }}
                          transition={{ duration: 1, delay: i * 0.05 + 0.3, ease: "easeOut" }}
                          className={`h-full bg-gradient-to-r ${gradientColor} rounded-full`}
                        />
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
