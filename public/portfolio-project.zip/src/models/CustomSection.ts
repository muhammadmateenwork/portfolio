import mongoose, { Schema, Document } from "mongoose";

export interface ICustomSection extends Document {
  sectionKey: string;
  title: string;
  subtitle: string;
  content: string;
  type: string;
  visible: boolean;
  order: number;
}

const CustomSectionSchema = new Schema<ICustomSection>({
  sectionKey: { type: String, required: true, unique: true, trim: true },
  title: { type: String, required: true, trim: true },
  subtitle: { type: String, default: "" },
  content: { type: String, default: "" },
  type: { type: String, default: "text", enum: ["text", "markdown", "html"] },
  visible: { type: Boolean, default: true },
  order: { type: Number, default: 0 },
});

CustomSectionSchema.set("toJSON", {
  transform: (_doc, ret) => {
    ret.id = ret._id.toString();
    delete ret._id;
    delete ret.__v;
    return ret;
  },
});

export default mongoose.models.CustomSection || mongoose.model<ICustomSection>("CustomSection", CustomSectionSchema);
